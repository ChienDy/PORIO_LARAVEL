<?php $__env->startSection("content"); ?>
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">   
          <h1>MY ACADEMIC SCHEDULE</h1>
              <div class="panel panel-default">
              	
              	<table class="table" style="width:100%;font-size:30px" >
				  <tr>
				    <th>SUBJECT NAME</th>
				  </tr>
				  <tr>
				  <td>ITELEC-EMSYS</td>
				  </tr>
				   <tr>
				  <td>ITELEC-PHP2</td>
				  </tr>
				   <tr>
				  <td>SOFTENG32</td>
				  </tr>
				   <tr>
				  <td>RESARCH 1</td>
				  </tr>
				   <tr>
				  <td>AIS32</td>
				  </tr>
				   <tr>
				  <td>FREEEL-PM</td>
				  </tr>
				</table>
				
              </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>