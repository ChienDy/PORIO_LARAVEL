<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>MY SOCIAL MEDIA ACCOUNTS</h1>

              <div class="panel panel-default">
              	<H3>
  				Instagram Account: ryanm0514<BR><BR>
  				 Facebook Account: https://www.facebook.com/ryanandrew.montes<BR><BR>
              </H3>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>