@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>
          <br><br>
          <div class="panel panel-default">
          	<div class="panel-body">
         	<H4 style="margin-left:20px">Hello Good Day :)<BR></H4>
          <H4 style="margin-left:20px">I am Chiendy Mae Porio.
          <H4 style="margin-left:20px">I reside at Labangon Cebu City.<BR></H4>
          <H4 style="margin-left:20px">I am currently study at University of Cebu, taking up Bachelor of Science in Information Technology.<BR></H4>
          <H4 style="margin-left:20px">I have four siblings, two brothers and two sisters.<BR></H4>
          <H4 style="margin-left:20px">I have brown eyes and black short hair.<BR></H4>
          <H4 style="margin-left:20px">I stand 5'3 tall.<BR></H4>
          <H4 style="margin-left:20px">My hobbies are reading, watching movies, and eating.<BR></H4>
          <H4 style="margin-left:20px">I can sing and dance.<BR></H4>
          <H4 style="margin-left:20px">I dance randomly.<BR></H4>
          <H4 style="margin-left:20px">I have an obsession with books, they are my remedy whenever I get bored and such.<BR></H4>
          <H4 style="margin-left:20px">Harry Potter is my favorite series.<BR></H4>
          <H4 style="margin-left:20px">I have an addiction to my phone, coz all my stuff such as ebooks, pdf and etc. are stored there.<BR></H4>
          <H4 style="margin-left:20px">I am one of the most sarcastic person you will ever meet, and I think it runs in the family.<BR></H4>
          <H4 style="margin-left:20px">I have friends, they are crazy at all times and hilarious sometimes.<BR></H4>
          <H4 style="margin-left:20px">I love talking to my friends random things.<BR></H4>
          <H4 style="margin-left:20px">Some of my friends thinks of me as funny.<BR></H4>
          <H4 style="margin-left:20px">I consider myself a very genuine and compassionate person<BR></H4>
          <H4 style="margin-left:20px">I don't spend too much time on the internet.<BR></H4>
          <H4 style="margin-left:20px">I may be fat/chubby, but I love eating nutritious foods.<BR></H4>
         </div>
         </div>
              

        </div>
    </div>
</div>

@stop