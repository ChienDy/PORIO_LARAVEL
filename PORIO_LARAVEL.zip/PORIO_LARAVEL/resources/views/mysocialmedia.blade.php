@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>MY SOCIAL MEDIA ACCOUNTS</h1>

              <div class="panel panel-default" style="margin-top:60px;">
              	
                  <table class="table"><tr><td style="font-size:28px">
  				 Facebook Account: <a href="https://www.facebook.com/qedazc">https://www.facebook.com/chien.mae.9</a>
          </td></tr></table>
              
              </div>
            </div>
        </div>
    </div>
</div>
@stop